alter("我是外部js文件中的代码")
