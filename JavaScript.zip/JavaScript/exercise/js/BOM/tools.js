// tools.js

// 创建一个可以设置动画效果的函数
// 参数
//  obj：要执行动画的对象
// speed：移动的速度
// target：执行函数的目标位置
// attr：要执行动画的样式，比如left top width height
// callback：传递一个回调函数，该函数会在动画执行完毕后执行
function move(obj, attr, target, speed, callback) {
	// 关闭上一个定时器
	clearInterval(obj.timer);

	// 获取obj当前的位置
	var current = parseInt(getStyle(obj, attr));

	// 判断速度的正负值
	// 如果为从0向800，则为正值
	// 如果是从800向0，则为负值
	if (current > target) {
		// 此时速度应为负值
		speed = -speed;
	}

	// 开启一个定时器用来执行动画效果
	obj.timer = setInterval(function() {
		// 获取obj原来的left值
		var oldValue = parseInt(getStyle(obj, attr));
		// alert(oldValue);
		// 在旧值的基础上减小
		var newValue = oldValue + speed;

		// 判断newValue与最终位置的关系
		// 当向左移动时，要看新值是否小于target
		// 当向右移动时，要看新值是否大于target
		if ((speed < 0 && newValue < target) || (speed > 0 && newValue > target)) {
			newValue = target;
		}

		// 将新值设置给obj
		// 书写方式为style[]的形式
		obj.style[attr] = newValue + "px";

		// 当元素移动到0px的时候，使其停止动画
		if (newValue == target) {
			// 达到目标，关闭定时器
			clearInterval(obj.timer);
			// 如果有回调函数，则调用，否则不调用
			callback && callback();
		}
	}, 30);
};

function getStyle(obj, name) {
	// 在正常的浏览器中，存在getComputeStyle()方法，但是在ie8中没有，可以利用这一点作为判断浏览器的条件
	// 这里加上window指明了对象，没有找到，将返回false；如果去掉window，则是作为一个变量寻找，找不到时将会报错
	// 本质上，这里使用currentStyle方法也可以，区别在于不同的浏览器
	if (window.getComputedStyle) {
		// 正常浏览器的方式
		return getComputedStyle(obj, null)[name];
	} else {
		// ie8的方式
		return obj.currentStyle[name];
	}
};

// 定义一个工具函数，功能：向一个元素中添加指定的class属性值
// 参数：
// obj : 需要被添加class的元素
// cn : 要添加的class值
function addClass(obj, cn) {
	// 检查obj中是否含有cn 
	if (!hasClass(obj, cn)) {
		obj.className += " " + cn;
	}
}

// 定义一个工具函数，功能：判断一个元素中是否含有class属性值
// 参数：
// obj : 需要被判断class的元素
// cn : 被判断的class值
function hasClass(obj, cn) {
	// 判断obj中是否有cn这个className
	// 创建一个正则表达式:\b表示单词边界，用来指明有与cn完全相同的类名
	// 注意这里要通过构造函数的方式构造正则表达式，不能使用var reg = /\bb2\b/;
	// 由于转义字符的存在，这一用的是\\b
	var reg = new RegExp("\\b" + cn + "\\b");

	return reg.text(obj.className);
}

// 定义一个工具函数，功能：删除一个元素中制定的class属性
// 参数：
// obj : 需要被删除class的元素
// cn : 被删除的class值
function removeClass(obj, cn) {
	// 思路：将某指定的cn替换为空串
	// 创建一个正则表达式
	var reg = new RegExp("\\b" + cn + "\\b");
	// 删除正则表达式中的内容
	obj.className = obj.className.replace(reg, "")
}

// 定义一个工具函数，切换一个类:如果函数中有该类，则删除；如果元素中没有该类，则添加
function toggleClass(obj, cn) {
	if (hasClass(obj, cn)) {
		addClass(obj, cn);
	} else {
		removeClass(obj, cn);
	}
}
